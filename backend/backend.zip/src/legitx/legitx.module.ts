import { Module } from '@nestjs/common';
import { LegitxDashboardController } from './legitx-dashboard.controller';
import { LegitxDashboardService } from './legitx-dashboard.service';
import { LegitxComplianceController } from './legitx-compliance.controller';
import { LegitxComplianceService } from './legitx-compliance.service';
import { DbService } from '../common/db/db.service';

@Module({
  imports: [],
  controllers: [LegitxDashboardController, LegitxComplianceController],
  providers: [LegitxDashboardService, LegitxComplianceService, DbService],
  exports: [LegitxDashboardService, LegitxComplianceService],
})
export class LegitxModule {}
