import { Controller, Get, Param, Query, Req, UseGuards } from '@nestjs/common';
import { LegitxReadOnlyGuard } from '../auth/policies/legitx-readonly.guard';
import { LegitxComplianceService } from './legitx-compliance.service';

@UseGuards(LegitxReadOnlyGuard)
@Controller({ path: 'legitx', version: '1' })
export class LegitxComplianceController {
  constructor(private readonly svc: LegitxComplianceService) {}

  @Get('compliance-status')
  async complianceStatus(@Req() req: any, @Query() q: any) {
    const month = this.toInt(q.month, new Date().getMonth() + 1);
    const year = this.toInt(q.year, new Date().getFullYear());
    return this.svc.getComplianceStatus({
      month,
      year,
      branchId: q.branchId || null,
      lawType: q.lawType || null,
      status: q.status || null,
      clientId: req.user?.clientId ?? null,
    });
  }

  @Get('mcd')
  async listMcd(@Req() req: any, @Query() q: any) {
    const month = this.toInt(q.month, new Date().getMonth() + 1);
    const year = this.toInt(q.year, new Date().getFullYear());
    return this.svc.getMcdList({
      month,
      year,
      branchId: q.branchId || null,
      status: q.status || null,
      clientId: req.user?.clientId ?? null,
    });
  }

  @Get('returns')
  async listReturns(@Req() req: any, @Query() q: any) {
    const month = this.toInt(q.month, new Date().getMonth() + 1);
    const year = this.toInt(q.year, new Date().getFullYear());
    return this.svc.getReturns({
      month,
      year,
      branchId: q.branchId || null,
      lawType: q.lawType || null,
      status: q.status || null,
      clientId: req.user?.clientId ?? null,
    });
  }

  @Get('returns/:id/download')
  async downloadReturn(@Req() req: any, @Param('id') id: string) {
    return this.svc.getReturnDownload(id, req.user?.clientId ?? null);
  }

  @Get('audits')
  async listAudits(@Req() req: any, @Query() q: any) {
    const month = this.toInt(q.month, new Date().getMonth() + 1);
    const year = this.toInt(q.year, new Date().getFullYear());
    return this.svc.getAudits({
      month,
      year,
      branchId: q.branchId || null,
      status: q.status || null,
      clientId: req.user?.clientId ?? null,
    });
  }

  @Get('audits/:auditId/report/download')
  async downloadAuditReport(
    @Req() req: any,
    @Param('auditId') auditId: string,
  ) {
    return this.svc.getAuditReportDownload(auditId, req.user?.clientId ?? null);
  }

  @Get('audits/:auditId/observations')
  async auditObservations(@Param('auditId') auditId: string) {
    return this.svc.getAuditObservations(auditId);
  }

  private toInt(value: any, fallback: number) {
    const n = parseInt(value, 10);
    return Number.isFinite(n) ? n : fallback;
  }
}
