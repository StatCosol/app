import { Controller, Get, Query, Req } from '@nestjs/common';
import { Roles } from '../auth/roles.decorator';
import { LegitxDashboardService } from './legitx-dashboard.service';

@Controller({ path: 'legitx/dashboard', version: '1' })
export class LegitxDashboardController {
  constructor(private readonly dashboardService: LegitxDashboardService) {}

  @Roles('CLIENT', 'CEO', 'CCO', 'CRM', 'AUDITOR', 'PAYROLL', 'ADMIN')
  @Get()
  async base(@Req() req: any, @Query() query: any) {
    return this.dashboardService.getSummary(req.user?.id, query);
  }

  @Roles('CLIENT', 'CEO', 'CCO', 'CRM', 'AUDITOR', 'PAYROLL', 'ADMIN')
  @Get('summary')
  async summary(@Req() req: any, @Query() query: any) {
    return this.dashboardService.getSummary(req.user?.id, query);
  }
}
